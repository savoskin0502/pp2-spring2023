import os

# print(os.environ)
print(os.environ['PATH'])
print(os.getenv('----', '123'))
# PATH
# HOME
# SPARK_HOME; JAVA_HOME
