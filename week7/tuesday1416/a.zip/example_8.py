import os

os.mkdir('./new')
print(os.listdir('.'))
os.makedirs('./tests1/subtests1/subsubtests1')
os.rmdir('./tests1')
