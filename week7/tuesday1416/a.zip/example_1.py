f = open('rawdata.txt', mode='w')
print(f)

# open
# read
# rename
# write
# create
# close
# move
