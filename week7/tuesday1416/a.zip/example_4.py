
with open('rawdata.txt', mode='r') as f:
    print(f.read())
